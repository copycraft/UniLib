package nazario.liby.api.registry.runtime.models;

import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.List;
import net.minecraft.class_9824;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;

public class LibyVariantBlockState extends LibyBlockState {

    public HashMap<ModelResourceLocation, JsonObject> modelIdentifierMap;

    public LibyVariantBlockState(ResourceLocation id, String resourcePackName) {
        this(id, resourcePackName, new HashMap<>());
    }


    public LibyVariantBlockState(ResourceLocation id, String resourcePackName, HashMap<ModelResourceLocation, JsonObject> jsonIdentifiers) {
        this.id = id;
        this.resourcePackName = resourcePackName;
        this.modelIdentifierMap = jsonIdentifiers;
    }

    public LibyBlockState addState(String variant, String model) {
        return this.addState(variant, model, 0, 0, false, 1);
    }

    public LibyBlockState addState(String variant, String model, int x_rotation, int y_rotation, boolean uv_lock, int weight) {
        JsonObject jsonObject = new JsonObject();

        jsonObject.addProperty("model", model);
        jsonObject.addProperty("x", x_rotation);
        jsonObject.addProperty("y", y_rotation);
        jsonObject.addProperty("uv_lock", uv_lock);
        jsonObject.addProperty("weight", weight);

        this.modelIdentifierMap.put(new ModelResourceLocation(id, variant), jsonObject);

        return this;
    }

    @Override
    public List<class_9824.class_7777> createTrackedData() {
        JsonObject mainJson = new JsonObject();
        JsonObject variants = new JsonObject();

        for(ModelResourceLocation modelId : modelIdentifierMap.keySet()) {
            JsonObject jsonObject = modelIdentifierMap.get(modelId);

            variants.add(modelId.getVariant(), jsonObject);
        }

        mainJson.add("variants", variants);

        return List.of(new class_9824.class_7777(resourcePackName, mainJson));
    }


    public JsonObject getModel(ModelResourceLocation modelIdentifier) {
        return modelIdentifierMap.get(modelIdentifier);
    }
}
