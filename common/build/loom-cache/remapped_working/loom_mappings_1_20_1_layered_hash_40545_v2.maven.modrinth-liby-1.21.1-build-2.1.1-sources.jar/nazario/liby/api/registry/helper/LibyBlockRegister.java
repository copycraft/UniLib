package nazario.liby.api.registry.helper;

import nazario.liby.registry.AbstractRegister;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import java.util.function.BiFunction;

public class LibyBlockRegister extends AbstractRegister {

    public LibyBlockRegister(String namespace) {
        super(namespace);
    }

    public Block registerBlock(String id, Block block) {
        return Registry.register(BuiltInRegistries.BLOCK, ResourceLocation.method_60655(namespace, id), block);
    }

    public Block registerBlock(String id, Block block, Item.Properties itemSettings) {
        Registry.register(BuiltInRegistries.ITEM, ResourceLocation.method_60655(namespace, id), new BlockItem(block, itemSettings));
        return registerBlock(id, block);
    }

    public Block registerBlock(String id, Block block, BlockItem item) {
        Registry.register(BuiltInRegistries.ITEM, ResourceLocation.method_60655(namespace, id), item);
        return registerBlock(id, block);
    }

    public Block registerBlock(String id, Block block, BiFunction<Block, Item.Properties, BlockItem> itemFactory) {
        Registry.register(BuiltInRegistries.ITEM, ResourceLocation.method_60655(namespace, id), itemFactory.apply(block, new Item.Properties()));
        return registerBlock(id, block);
    }

    public <T extends BlockEntityType<?>> T registerBlockEntityType(String name, T blockEntityType) {
        return Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, ResourceLocation.method_60655(namespace, name), blockEntityType);
    }

}
