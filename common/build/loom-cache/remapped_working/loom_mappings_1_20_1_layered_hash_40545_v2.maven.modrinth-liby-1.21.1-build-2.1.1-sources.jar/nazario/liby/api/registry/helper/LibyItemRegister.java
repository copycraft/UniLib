package nazario.liby.api.registry.helper;

import nazario.liby.registry.AbstractRegister;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import java.util.function.Function;

public class LibyItemRegister extends AbstractRegister {
    public LibyItemRegister(String namespace) {
        super(namespace);
    }

    public Item registerItem(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, ResourceLocation.method_60655(namespace, name), item);
    }

    public Item registerItem(String name, Function<Item.Properties, Item> itemFunction) {
        return registerItem(name, itemFunction.apply(new Item.Properties()));
    }
}
