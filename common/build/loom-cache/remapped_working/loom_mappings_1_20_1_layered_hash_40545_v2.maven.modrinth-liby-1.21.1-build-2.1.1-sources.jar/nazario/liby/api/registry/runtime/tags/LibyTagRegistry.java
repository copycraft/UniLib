package nazario.liby.api.registry.runtime.tags;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagEntry;
import net.minecraft.tags.TagLoader;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

public class LibyTagRegistry {

    @ApiStatus.Internal
    private static final HashMap<String, HashMap<ResourceLocation, List<TagLoader.EntryWithSource>>> MAP = new HashMap<>();

    public static HashMap<String, HashMap<ResourceLocation, List<TagLoader.EntryWithSource>>> getMap() {
        return MAP;
    }

    public static void add(String tagType, ResourceLocation tag, String source, TagEntry... tagEntries) {
        // Initialize a list to store tracked entries
        List<TagLoader.EntryWithSource> list = new ArrayList<>();

        // Convert TagEntry objects to TrackedEntry objects and add to the list
        for (TagEntry tagEntry : tagEntries) {
            list.add(new TagLoader.EntryWithSource(tagEntry, source));
        }

        // Retrieve existing entries for the given tagType and tag, if any
        HashMap<ResourceLocation, List<TagLoader.EntryWithSource>> tagMap = MAP.getOrDefault(tagType, new HashMap<>());
        List<TagLoader.EntryWithSource> existingEntries = tagMap.getOrDefault(tag, new ArrayList<>());

        // Add existing entries to the list
        list.addAll(existingEntries);

        // Update the tagMap with the combined list
        tagMap.put(tag, list);

        // Update the main map with the updated tagMap
        MAP.put(tagType, tagMap);
    }

    public static void addBlocks(ResourceLocation tag, String source, Block @NotNull ... blocks) {
        List<TagEntry> tagEntries = new ArrayList<>();

        for (Block block : blocks) {
            tagEntries.add(TagEntry.element(block.liby$getId()));
        }

        LibyTagRegistry.add(TagTypes.BLOCKS, tag, source, tagEntries.toArray(TagEntry[]::new));
    }

    public static void addItems(ResourceLocation tag, String source, Item @NotNull ... items) {
        List<TagEntry> tagEntries = new ArrayList<>();

        for (Item item : items) {
            tagEntries.add(TagEntry.element(item.liby$getId()));
        }

        LibyTagRegistry.add(TagTypes.ITEMS, tag, source, tagEntries.toArray(TagEntry[]::new));
    }

    public static final class TagTypes {
        public static final String ACTIVITY = "tags/activity";
        public static final String ARMOR_MATERIAL = "tags/armor_material";
        public static final String ATTRIBUTE = "tags/attribute";
        public static final String BANNER_PATTERN = "tags/banner_pattern";
        public static final String BLOCKS = "tags/block";
        public static final String BLOCK_ENTITY_TYPE = "tags/block_entity_type";
        public static final String BLOCK_PREDICATE_TYPE = "tags/block_predicate_type";
        public static final String BLOCK_TYPE = "tags/block_type";
        public static final String CAT_VARIANT = "tags/cat_variant";
        public static final String CHAT_TYPE = "tags/chat_type";
        public static final String CHUNK_STATUS = "tags/chunk_status";
        public static final String COMMAND_ARGUMENT_TYPE = "tags/command_argument_type";
        public static final String CREATIVE_MODE_TAB = "tags/creative_mode_tab";
        public static final String CUSTOM_STAT = "tags/custom_stat";
        public static final String DAMAGE_TYPE = "tags/damage_type";
        public static final String DATA_COMPONENT_TYPE = "tags/data_component_type";
        public static final String DECORATED_POT_PATTERN = "tags/decorated_pot_pattern";
        public static final String DIMENSION = "tags/dimension";
        public static final String DIMENSION_TYPE = "tags/dimension_type";
        public static final String ENCHANTMENT = "tags/enchantment";
        public static final String ENCHANTMENT_EFFECT_COMPONENT_TYPE = "tags/enchantment_effect_component_type";
        public static final String ENCHANTMENT_ENTITY_EFFECT_TYPE = "tags/enchantment_entity_effect_type";
        public static final String ENCHANTMENT_LEVEL_BASED_VALUE_TYPE = "tags/enchantment_level_based_value_type";
        public static final String ENCHANTMENT_LOCATION_BASED_EFFECT_TYPE = "tags/enchantment_location_based_effect_type";
        public static final String ENCHANTMENT_PROVIDER = "tags/enchantment_provider";
        public static final String ENCHANTMENT_PROVIDER_TYPE = "tags/enchantment_provider_type";
        public static final String ENCHANTMENT_VALUE_EFFECT_TYPE = "tags/enchantment_value_effect_type";
        public static final String ENTITY_SUB_PREDICATE_TYPE = "tags/entity_sub_predicate_type";
        public static final String ENTITY_TYPE = "tags/entity_type";
        public static final String FLOAT_PROVIDER_TYPE = "tags/float_provider_type";
        public static final String FLUID = "tags/fluid";
        public static final String FROG_VARIANT = "tags/frog_variant";
        public static final String FUNCTION = "tags/function";
        public static final String GAME_EVENT = "tags/game_event";
        public static final String HEIGHT_PROVIDER_TYPE = "tags/height_provider_type";
        public static final String INSTRUMENT = "tags/instrument";
        public static final String INT_PROVIDER_TYPE = "tags/int_provider_type";
        public static final String ITEMS = "tags/item";
        public static final String ITEM_MODIFIER = "tags/item_modifier";
        public static final String ITEM_SUB_PREDICATE_TYPE = "tags/item_sub_predicate_type";
        public static final String JUKEBOX_SONG = "tags/jukebox_song";
        public static final String LOOT_CONDITION_TYPE = "tags/loot_condition_type";
        public static final String LOOT_FUNCTION_TYPE = "tags/loot_function_type";
        public static final String LOOT_NBT_PROVIDER_TYPE = "tags/loot_nbt_provider_type";
        public static final String LOOT_NUMBER_PROVIDER_TYPE = "tags/loot_number_provider_type";
        public static final String LOOT_POOL_ENTRY_TYPE = "tags/loot_pool_entry_type";
        public static final String LOOT_SCORE_PROVIDER_TYPE = "tags/loot_score_provider_type";
        public static final String LOOT_TABLE = "tags/loot_table";
        public static final String MAP_DECORATION_TYPE = "tags/map_decoration_type";
        public static final String MEMORY_MODULE_TYPE = "tags/memory_module_type";
        public static final String MENU = "tags/menu";
        public static final String MOB_EFFECT = "tags/mob_effect";
        public static final String NUMBER_FORMAT_TYPE = "tags/number_format_type";
        public static final String PAINTING_VARIANT = "tags/painting_variant";
        public static final String PARTICLE_TYPE = "tags/particle_type";
        public static final String POINT_OF_INTEREST_TYPE = "tags/point_of_interest_type";
        public static final String POSITION_SOURCE_TYPE = "tags/position_source_type";
        public static final String POS_RULE_TEST = "tags/pos_rule_test";
        public static final String POTION = "tags/potion";
        public static final String PREDICATE = "tags/predicate";
        public static final String RECIPE_SERIALIZER = "tags/recipe_serializer";
        public static final String RECIPE_TYPE = "tags/recipe_type";
        public static final String RULE_BLOCK_ENTITY_MODIFIER = "tags/rule_block_entity_modifier";
        public static final String RULE_TEST = "tags/rule_test";
        public static final String SCHEDULE = "tags/schedule";
        public static final String SENSOR_TYPE = "tags/sensor_type";
        public static final String SOUND_EVENT = "tags/sound_event";
        public static final String STAT_TYPE = "tags/stat_type";
        public static final String TRIGGER_TYPE = "tags/trigger_type";
        public static final String TRIM_MATERIAL = "tags/trim_material";
        public static final String TRIM_PATTERN = "tags/trim_pattern";
        public static final String VILLAGER_PROFESSION = "tags/villager_profession";
        public static final String VILLAGER_TYPE = "tags/villager_type";
        public static final String WOLF_VARIANT = "tags/wolf_variant";
        public static final String WORLDGEN_BIOME = "tags/worldgen/biome";
        public static final String WORLDGEN_BIOME_SOURCE = "tags/worldgen/biome_source";
        public static final String WORLDGEN_BLOCK_STATE_PROVIDER_TYPE = "tags/worldgen/block_state_provider_type";
        public static final String WORLDGEN_CARVER = "tags/worldgen/carver";
        public static final String WORLDGEN_CHUNK_GENERATOR = "tags/worldgen/chunk_generator";
        public static final String WORLDGEN_CONFIGURED_CARVER = "tags/worldgen/configured_carver";
        public static final String WORLDGEN_CONFIGURED_FEATURE = "tags/worldgen/configured_feature";
        public static final String WORLDGEN_DENSITY_FUNCTION = "tags/worldgen/density_function";
        public static final String WORLDGEN_DENSITY_FUNCTION_TYPE = "tags/worldgen/density_function_type";
        public static final String WORLDGEN_FEATURE = "tags/worldgen/feature";
        public static final String WORLDGEN_FEATURE_SIZE_TYPE = "tags/worldgen/feature_size_type";
        public static final String WORLDGEN_FLAT_LEVEL_GENERATOR_PRESET = "tags/worldgen/flat_level_generator_preset";
        public static final String WORLDGEN_FOLIAGE_PLACER_TYPE = "tags/worldgen/foliage_placer_type";
        public static final String WORLDGEN_MATERIAL_CONDITION = "tags/worldgen/material_condition";
        public static final String WORLDGEN_MATERIAL_RULE = "tags/worldgen/material_rule";
        public static final String WORLDGEN_MULTI_NOISE_BIOME_SOURCE_PARAMETER_LIST = "tags/worldgen/multi_noise_biome_source_parameter_list";
        public static final String WORLDGEN_NOISE = "tags/worldgen/noise";
        public static final String WORLDGEN_NOISE_SETTINGS = "tags/worldgen/noise_settings";
        public static final String WORLDGEN_PLACED_FEATURE = "tags/worldgen/placed_feature";
        public static final String WORLDGEN_PLACEMENT_MODIFIER_TYPE = "tags/worldgen/placement_modifier_type";
        public static final String WORLDGEN_POOL_ALIAS_BINDING = "tags/worldgen/pool_alias_binding";
        public static final String WORLDGEN_PROCESSOR_LIST = "tags/worldgen/processor_list";
        public static final String WORLDGEN_ROOT_PLACER_TYPE = "tags/worldgen/root_placer_type";
        public static final String WORLDGEN_STRUCTURE = "tags/worldgen/structure";
        public static final String WORLDGEN_STRUCTURE_PIECE = "tags/worldgen/structure_piece";
        public static final String WORLDGEN_STRUCTURE_PLACEMENT = "tags/worldgen/structure_placement";
        public static final String WORLDGEN_STRUCTURE_POOL_ELEMENT = "tags/worldgen/structure_pool_element";
        public static final String WORLDGEN_STRUCTURE_PROCESSOR = "tags/worldgen/structure_processor";
        public static final String WORLDGEN_STRUCTURE_SET = "tags/worldgen/structure_set";
        public static final String WORLDGEN_STRUCTURE_TYPE = "tags/worldgen/structure_type";
        public static final String WORLDGEN_TEMPLATE_POOL = "tags/worldgen/template_pool";
        public static final String WORLDGEN_TREE_DECORATOR_TYPE = "tags/worldgen/tree_decorator_type";
        public static final String WORLDGEN_TRUNK_PLACER_TYPE = "tags/worldgen/trunk_placer_type";
        public static final String WORLDGEN_WORLD_PRESET = "tags/worldgen/world_preset";
    }

}
