package nazario.liby.api.util.particle;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class LibyParticleData {
    public ParticleOptions particleEffect;
    public Vec3 velocity;
    public Level world;
    public boolean important;
    public boolean alwaysSpawns;

    public LibyParticleData(Level world, ParticleOptions particleEffect, Vec3 velocity, boolean important, boolean alwaysSpawns) {
        this.particleEffect = particleEffect;
        this.velocity = velocity;
        this.world = world;
        this.important = important;
        this.alwaysSpawns = alwaysSpawns;
    }
}
