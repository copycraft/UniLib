package nazario.liby.api.registry.rendering;

import nazario.liby.api.registry.runtime.models.LibyItemModelObject;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.ItemLike;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LibyItemSpecialModelRegistry {
    @ApiStatus.Internal
    protected static final HashMap<ItemLike, LibyItemModelObject> renderList = new HashMap<>();

    @ApiStatus.Internal
    protected static final List<ModelResourceLocation> modelList = new ArrayList<>();

    public static void register(ItemLike itemConvertible, ModelResourceLocation modelIdentifier, ItemDisplayContext... modes) {
        renderList.put(itemConvertible, new LibyItemModelObject(itemConvertible, modelIdentifier, modes));
    }

    public static HashMap<ItemLike, LibyItemModelObject> getList() {
        return renderList;
    }

    @ApiStatus.Internal
    public static List<ModelResourceLocation> _getModelList() {
        return modelList;
    }

    @ApiStatus.Internal
    public static void _addModel(ModelResourceLocation modelIdentifier) {
        modelList.add(modelIdentifier);
    }
}