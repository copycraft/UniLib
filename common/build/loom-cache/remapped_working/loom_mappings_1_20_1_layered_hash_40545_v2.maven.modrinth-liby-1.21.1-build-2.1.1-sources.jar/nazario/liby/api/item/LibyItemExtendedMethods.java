package nazario.liby.api.item;

import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;

public interface LibyItemExtendedMethods {
    default Optional<Item.Properties> liby$getItemSettings() {
        return Optional.empty();
    }

    default ResourceLocation liby$getId() {
        return null;
    }
}
