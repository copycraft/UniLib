package nazario.liby.api.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import nazario.liby.api.registry.runtime.models.LibyJsonModel;
import nazario.liby.api.registry.runtime.models.LibyModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Tuple;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;

public class LibyModelHelper {
    public static LibyModel createItemGenerated(ItemLike convertible, ResourceLocation... spriteIdentifier) {
        return createItemCustom(convertible, spriteIdentifier, "minecraft:item/generated");
    }

    public static LibyModel createBlock(Block block, ResourceLocation parentModel, ResourceLocation... textures) {
        ResourceLocation id = block.liby$getId();

        JsonObject model = new JsonObject();

        model.addProperty("parent", parentModel.toString());

        JsonObject textureObject = new JsonObject();

        textureObject.addProperty("particle", textures[0].toString());

        for(int i = 0;i<textures.length;i++) {
            textureObject.addProperty(String.valueOf(i), textures[i].toString());
        }

        model.add("textures", textureObject);

        return new LibyJsonModel(ResourceLocation.method_60655(id.getNamespace(), "block/" + id.getPath()), "", model, "block");
    }

    public static LibyModel createBlockItem(Block block) {
        ResourceLocation id = block.liby$getId();

        JsonObject model = new JsonObject();

        model.addProperty("parent", ResourceLocation.method_60655(id.getNamespace(), "block/" + id.getPath()).toString());

        return new LibyJsonModel(ResourceLocation.method_60655(id.getNamespace(), "item/" + id.getPath()), "", model, "item");
    }

    public static LibyModel createParentModel(ModelResourceLocation modelId, ResourceLocation parentId, String modelType) {
        JsonObject model = new JsonObject();

        model.addProperty("parent", parentId.toString());

        return new LibyJsonModel(modelId, model, modelType);
    }

    public static LibyModel createItemCustom(ItemLike convertible, ResourceLocation[] spriteIdentifier, String parentModel) {
        return createItemCustom(ModelResourceLocation.method_61078(convertible.asItem().liby$getId()), spriteIdentifier, parentModel);
    }

    public static LibyModel createItemCustom(ModelResourceLocation id, ResourceLocation[] spriteIdentifier, String parentModel) {

        JsonObject model = new JsonObject();

        model.addProperty("parent", parentModel);

        JsonObject texturesObject = new JsonObject();

        for(int i = 0;i<spriteIdentifier.length;i++) {
            texturesObject.addProperty("layer" + i, spriteIdentifier[i].toString());
        }

        return new LibyJsonModel(id.comp_2875().method_45138("item/"), id.getVariant(), model, "item");
    }

    public static LibyModel createCustom(ModelResourceLocation id, Tuple<String, ResourceLocation>[] spriteKeyPair, String parentModel, String modelType) {

        JsonObject model = new JsonObject();

        model.addProperty("parent", parentModel);

        JsonObject texturesObject = new JsonObject();

        for(Tuple<String, ResourceLocation> pair : spriteKeyPair) {
            texturesObject.addProperty(pair.getA(), pair.getB().toString());
        }

        model.add("textures", texturesObject);

        return new LibyJsonModel(id, model, modelType);
    }

    public static LibyModel createFromJson(ResourceLocation id, String json, String modelType) {
        return new LibyJsonModel(id, "", JsonParser.parseString(json).getAsJsonObject(), modelType);
    }

    public static LibyModel createFromJson(ResourceLocation id, JsonObject object, String modelType) {
        return new LibyJsonModel(id, "", object, modelType);
    }
}
