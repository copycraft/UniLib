package nazario.liby.api.registry.itemgroup;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LibyItemGroup {
    public ResourceLocation id;
    public CreativeModeTab.Builder builder;
    public List<ItemStack> entriesList;

    public LibyItemGroup(ResourceLocation id, CreativeModeTab.Builder builder) {
        this.id = id;
        this.builder = builder;
        this.entriesList = new ArrayList<>();
    }

    public LibyItemGroup(ResourceLocation id, Component displayName) {
        this(id, FabricItemGroup.builder());
        this.builder.title(displayName);
    }

    public LibyItemGroup setBuilder(CreativeModeTab.Builder builder) {
        this.builder = builder;
        return this;
    }

    public CreativeModeTab.Builder getBuilder() {
        return this.builder;
    }

    public LibyItemGroup setIcon(ItemStack stack) {
        this.builder.icon(() -> stack);
        return this;
    }

    public LibyItemGroup setBackground(ResourceLocation texture) {
        this.builder.backgroundSuffix(texture);
        return this;
    }

    public LibyItemGroup addItem(ItemLike... itemConvertibles) {
        for(ItemLike convertible : itemConvertibles) {
            this.entriesList.add(new ItemStack(convertible));
        }
        return this;
    }

    public LibyItemGroup addItemStack(ItemStack stack) {
        this.entriesList.add(stack);
        return this;
    }

    public LibyItemGroup addItemStack(ItemStack... stacks) {
        this.entriesList.addAll(Arrays.asList(stacks));
        return this;
    }

    public CreativeModeTab build() {
        return builder.displayItems((context, entries) -> {
            entries.acceptAll(this.entriesList);
        }).build();
    }

    @ApiStatus.Internal
    public void register() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, this.id, this.build());
    }
}