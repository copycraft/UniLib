package nazario.liby.api.block.multiblock;

import nazario.liby.api.block.LibySetBlockListener;
import net.minecraft.block.*;
import net.minecraft.commands.arguments.blocks.BlockInput;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

public abstract class LibyMultiBlock extends BaseEntityBlock implements LibySetBlockListener {
    public static final BooleanProperty PARENT = BooleanProperty.create("parent");
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING; // Add facing property for horizontal placement

    public final VoxelShape SHAPE;

    public final BlockPos[] childBlocks;

    protected LibyMultiBlock(Properties settings, BlockPos[] childBlocks) {
        super(settings);

        this.childBlocks = childBlocks;
        this.SHAPE = createVoxelShape();
    }


    @Override
    public void setPlacedBy(Level world, BlockPos masterPos, BlockState masterState, LivingEntity placer, @Nullable ItemStack itemStack) {
        Direction facing;
        if (placer != null) {
            facing = placer.getDirection(); // Get player's facing direction
        } else {
            facing = masterState.getValue(FACING);
        }

        world.setBlockAndUpdate(masterPos, Blocks.AIR.defaultBlockState());

        for (int i = 0; i < childBlocks.length; i++) {
            BlockPos rotatedChildPos = rotateBlockPos(childBlocks[i], facing); // Rotate based on facing
            BlockPos childWorldPos = masterPos.offset(rotatedChildPos);

            world.setBlockAndUpdate(childWorldPos, masterState.setValue(PARENT, i == 0));

            ((LibyMultiBlockEntity) world.getBlockEntity(childWorldPos)).setParentPos(masterPos.offset(childBlocks[0]));
        }

        if (world.getBlockEntity(childBlocks[0]) instanceof LibyMultiBlockEntity multiblockEntity) {
            multiblockEntity.setParentPos(childBlocks[0]);
        }
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return this.defaultBlockState().setValue(FACING, Direction.fromYRot(ctx.getRotation()));
    }

    // Helper method to rotate BlockPos based on the facing direction
    private BlockPos rotateBlockPos(BlockPos pos, Direction facing) {
        return switch (facing) {
            case NORTH -> new BlockPos(-pos.getX(), pos.getY(), -pos.getZ());
            case SOUTH -> new BlockPos(pos.getX(), pos.getY(), pos.getZ());
            case WEST -> new BlockPos(-pos.getZ(), pos.getY(), pos.getX());
            case EAST -> new BlockPos(pos.getZ(), pos.getY(), -pos.getX());
            default -> pos;
        };
    }

    @Override
    public void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean moved) {
        if (state.equals(newState)) return;

        if (state.getValue(PARENT)) {
            for (BlockPos relativeChildPos : childBlocks) {
                BlockPos rotatedChildPos = rotateBlockPos(relativeChildPos, state.getValue(FACING));
                BlockPos childWorldPos = pos.offset(rotatedChildPos);

                BlockState childState = world.getBlockState(childWorldPos);
                if (childState.getBlock() instanceof LibyMultiBlock && !childState.getValue(PARENT)) {
                    // Set child block to air
                    world.setBlockAndUpdate(childWorldPos, Blocks.AIR.defaultBlockState());

                    // Safely handle the block entity
                    LibyMultiBlockEntity childEntity = getEntity(world, childWorldPos);
                    if (childEntity != null) {
                        childEntity.setDestroyed(true);
                    }
                }
            }
            // Set parent block to air
            world.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());

            // Call super after custom logic
            super.onRemove(state, world, pos, newState, moved);
            return;
        }

        if (newState.getBlock() instanceof LibyMultiBlock) {
            LibyMultiBlockEntity entity = getEntity(world, pos);
            if (entity != null && entity.isDestroyed() && !newState.getValue(PARENT)) {
                world.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
            }
        }

        if (state.getBlock() instanceof LibyMultiBlock) {
            LibyMultiBlockEntity entity = getEntity(world, pos);
            if (entity != null && !entity.isDestroyed() && !state.getValue(PARENT)) {
                BlockPos parentPos = entity.parentPos;
                BlockState parentState = world.getBlockState(parentPos);
                this.onRemove(parentState, world, parentPos, Blocks.AIR.defaultBlockState(), moved);
            }
        }

        super.onRemove(state, world, pos, newState, moved);
    }

    @Override
    @ApiStatus.Internal
    public InteractionResult method_55766(BlockState state, Level world, BlockPos pos, Player player, BlockHitResult hit) {
        if (!state.getValue(PARENT)) {
            LibyMultiBlockEntity entity = (LibyMultiBlockEntity) world.getBlockEntity(pos);
            if (entity.parentPos == null) return super.method_55766(state, world, pos, player, hit);
            return onMultiBlockUse(world, state, world.getBlockState(entity.parentPos), pos, entity.parentPos, player, hit);
        }

        return onMultiBlockUse(world, state, state, pos, pos, player, hit);
    }

    public InteractionResult onMultiBlockUse(Level world, BlockState clickedState, BlockState parentState, BlockPos clickedPos, BlockPos parentPos, Player player, BlockHitResult hit) {
        return InteractionResult.PASS;
    }


    @Override
    @ApiStatus.Internal
    public boolean canSurvive(BlockState state, LevelReader world, BlockPos pos) {
        Direction facing = state.getValue(FACING); // Get player's facing direction

        if (world.getBlockEntity(pos) instanceof LibyMultiBlockEntity multiblockEntity) {
            multiblockEntity.setParentPos(pos);
        }

        for (int i = 0; i < childBlocks.length; i++) {
            BlockPos rotatedChildPos = rotateBlockPos(childBlocks[i], facing); // Rotate based on facing
            BlockPos childWorldPos = pos.offset(rotatedChildPos);

            if (!world.getBlockState(childWorldPos).isAir()) return false;
        }

        return true;
    }

    @Override
    public void setBlockStateEventHead(BlockInput blockStateArgument, ServerLevel world, BlockPos pos, int flags, CallbackInfoReturnable<Boolean> cir) {
        BlockState blockState = LibyMultiBlock.updateFromNeighbourShapes(blockStateArgument.getState(), world, pos);
        this.setPlacedBy(world, pos, blockState, null, null);
        cir.setReturnValue(true);
    }

    //@Override
    //protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
    //    if(true) {
    //        return SHAPE;
    //    }
//
    //    LibyMultiBlockEntity entity = (LibyMultiBlockEntity)world.getBlockEntity(pos);
    //    if(entity == null) return super.getOutlineShape(state, world, pos, context);
//
    //    BlockPos parentPos = entity.parentPos;
    //    if(parentPos == null) return super.getOutlineShape(state, world, pos, context);
    //    BlockPos offset = pos.subtract(parentPos);
//
    //    return SHAPE.offset(offset.getX() * 16, offset.getY() * 16, offset.getZ() * 16);
    //}

    public VoxelShape createVoxelShape() {
        List<VoxelShape> shapes = new ArrayList<VoxelShape>();
        shapes.add(Block.box(0, 0, 0, 16, 16, 16));
        for (int i = 0; i < childBlocks.length; i++) {
            BlockPos childPos = childBlocks[i];

            shapes.add(Block.box(childPos.getX() * 16, childPos.getY() * 16, childPos.getZ() * 16,
                    childPos.getX() * 16 + 16, childPos.getY() * 16 + 16, childPos.getZ() * 16 + 16));
        }

        return shapes.stream().reduce((v1, v2) -> Shapes.join(v1, v2, BooleanOp.OR)).get();
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(PARENT, FACING); // Add FACING to block properties
    }

    public LibyMultiBlockEntity getParent(Level world, BlockPos pos) {
        if (world.getBlockEntity(pos) instanceof LibyMultiBlockEntity multiBlockEntity) {
            return (LibyMultiBlockEntity) world.getBlockEntity(multiBlockEntity.getParentPos());
        }

        return null;
    }

    public LibyMultiBlockEntity getEntity(Level world, BlockPos pos) {
        return (LibyMultiBlockEntity) world.getBlockEntity(pos);
    }
}
