package nazario.liby.api.util.nbt;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class LibyNbtCompoundReader {

    CompoundTag nbtCompound;

    public static LibyNbtCompoundReader create(CompoundTag nbtCompound) {
        return new LibyNbtCompoundReader(nbtCompound);
    }

    protected LibyNbtCompoundReader(CompoundTag nbtCompound) {
        this.nbtCompound = nbtCompound;
    }

    public Vec3 getVec3d(String key) {
        CompoundTag element = nbtCompound.getCompound(key);
        try {
            if (element.getString("type").equals("vec3d")) {
                return new Vec3(element.getDouble("x"), element.getDouble("y"), element.getDouble("z"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Vec3.ZERO;
    }

    public Vec3i getVec3i(String key) {
        CompoundTag element = nbtCompound.getCompound(key);

        try {
            if (element.getString("type").equals("vec3i")) {
                return new Vec3i(element.getInt("x"), element.getInt("y"), element.getInt("z"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Vec3i.ZERO;
    }

    public Vec2 getVec2f(String key) {
        CompoundTag element = nbtCompound.getCompound(key);

        try {
            if (element.getString("type").equals("vec2f")) {
                return new Vec2(element.getInt("x"), element.getInt("y"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Vec2.ZERO;
    }

    public BlockPos getBlockPos(String key) {
        CompoundTag element = nbtCompound.getCompound(key);

        try {
            if (element.getString("type").equals("blockpos")) {
                return new BlockPos(element.getInt("x"), element.getInt("y"), element.getInt("z"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return BlockPos.ZERO;
    }

    public float[] getFloatArray(String key) {
        CompoundTag element = nbtCompound.getCompound(key);

        try {
            if (element.getString("type").equals("floatArray")) {
                float[] array = new float[element.getInt("length")];
                for (int i = 0; i < array.length; i++) {
                    array[i] = element.getFloat(String.valueOf(i));
                }
                return array;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new float[]{};
    }

    public UUID[] getUUIDArray(String key) {
        CompoundTag element = nbtCompound.getCompound(key);

        try {
            if (element.getString("type").equals("uuidArray")) {
                UUID[] array = new UUID[element.getInt("length")];
                for (int i = 0; i < array.length; i++) {
                    array[i] = element.getUUID(String.valueOf(i));
                }
                return array;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new UUID[]{};
    }

    public EntityType<? extends Entity> getEntityType(String key) {
        CompoundTag element = nbtCompound.getCompound(key);

        try {
            if (element.getString("type").equals("entity_type")) {
                EntityType<? extends Entity> entityType = BuiltInRegistries.ENTITY_TYPE.stream()
                        .filter(entry -> entry.toString().equals(element.getString("entity_type")))
                        .findFirst()
                        .orElse(null);
                return entityType;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public CompoundTag getCompound(String key) {
        return nbtCompound.getCompound(key);
    }

    public LibyNbtCompoundReader getCompoundAsReader(String key) {
        return LibyNbtCompoundReader.create(getCompound(key));
    }

    public LibyNbtCompoundBuilder getCompoundAsBuilder(String key) {
        return LibyNbtCompoundBuilder.create(getCompound(key));
    }

    public boolean isPresent(String key) {
        return nbtCompound.contains(key);
    }

    public boolean isPresent(String key, int type) {
        return nbtCompound.contains(key, type);
    }

    public boolean isUuidPresent(String key) {
        return nbtCompound.hasUUID(key);
    }

    public CompoundTag asCompound() {
        return this.nbtCompound;
    }
}