package nazario.liby.api.registry.runtime.models;

import java.util.Arrays;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.ItemLike;

public final class LibyItemModelObject {
    public final ItemLike itemConvertible;
    public final ModelResourceLocation modelIdentifier;
    public final ItemDisplayContext[] modes;

    public LibyItemModelObject(ItemLike itemConvertible, ModelResourceLocation modelIdentifier, ItemDisplayContext... modes) {
        this.itemConvertible = itemConvertible;
        this.modelIdentifier = modelIdentifier;
        this.modes = modes;
    }

    public boolean containsMode(ItemDisplayContext mode) {
        return Arrays.stream(modes).toList().contains(mode);
    }
}