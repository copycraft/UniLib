package nazario.liby.api.block;

import net.minecraft.resources.ResourceLocation;

public interface LibyBlockExtendedMethods {
    default ResourceLocation liby$getId() {
        return null;
    }
}
