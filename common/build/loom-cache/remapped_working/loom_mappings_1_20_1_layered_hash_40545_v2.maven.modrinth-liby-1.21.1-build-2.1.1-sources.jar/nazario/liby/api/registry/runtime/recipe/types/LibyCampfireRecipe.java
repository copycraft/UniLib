package nazario.liby.api.registry.runtime.recipe.types;

import nazario.liby.api.registry.runtime.recipe.LibyIngredient;
import net.minecraft.resources.ResourceLocation;

public class LibyCampfireRecipe extends LibySmeltingRecipe {
    private static final ResourceLocation TYPE = ResourceLocation.method_60655("minecraft", "campfire_cooking");

    public LibyCampfireRecipe(ResourceLocation id, LibyIngredient ingredient, ResourceLocation result, double experience, int cookingTime) {
        super(id, ingredient, result, experience, cookingTime);
    }

    @Override
    protected ResourceLocation getType() {
        return TYPE;
    }
}
