package nazario.liby.api.registry.runtime.recipe;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;

public class LibyIngredient {
    protected final String type;
    protected final ResourceLocation identifier;
    protected final Character recipeCharacter;

    private LibyIngredient(String type, ResourceLocation identifier, Character recipeCharacter) {
        this.type = type;
        this.identifier = identifier;
        this.recipeCharacter = recipeCharacter;
    }

    public String getType() {
        return this.type;
    }

    public ResourceLocation getIngredientId() {
        return this.identifier;
    }

    public Character getRecipeCharacter() {
        return this.recipeCharacter;
    }

    public static LibyIngredient createItem(ResourceLocation id) {
        return new LibyIngredient("item", id, ' ');
    }

    public static LibyIngredient createItem(ResourceLocation id, Character recipeCharacter) {
        return new LibyIngredient("item", id, recipeCharacter);
    }

    public static LibyIngredient createItem(ItemLike itemConvertible) {
        return new LibyIngredient("item", itemConvertible.asItem().liby$getId(), ' ');
    }

    public static LibyIngredient createItem(ItemLike itemConvertible, Character recipeCharacter) {
        return new LibyIngredient("item", itemConvertible.asItem().liby$getId(), recipeCharacter);
    }

    public static LibyIngredient createTag(ResourceLocation tag) {
        return new LibyIngredient("tag", tag, ' ');
    }

    public static LibyIngredient createTag(ResourceLocation tag, Character recipeCharacter) {
        return new LibyIngredient("tag", tag, recipeCharacter);
    }

    public static LibyIngredient createTag(TagKey<Item> tagKey) {
        return new LibyIngredient("tag", tagKey.location(), ' ');
    }

    public static LibyIngredient createTag(TagKey<Item> tagKey, Character recipeCharacter) {
        return new LibyIngredient("tag", tagKey.location(), recipeCharacter);
    }
}
