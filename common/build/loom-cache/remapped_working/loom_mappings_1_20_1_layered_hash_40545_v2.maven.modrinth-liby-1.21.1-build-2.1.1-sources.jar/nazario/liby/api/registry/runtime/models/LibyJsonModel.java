package nazario.liby.api.registry.runtime.models;

import com.google.gson.JsonObject;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;

public class LibyJsonModel implements LibyModel {
    public final ModelResourceLocation identifier;
    public final JsonObject jsonModel;
    public final String modelType;

    public LibyJsonModel(ModelResourceLocation id, JsonObject jsonModel, String modelType) {
        this.identifier = id;
        this.jsonModel = jsonModel;
        this.modelType = modelType;
    }

    public LibyJsonModel(ResourceLocation id, String variant, JsonObject jsonModel, String modelType) {
        this(new ModelResourceLocation(id, variant), jsonModel, modelType);
    }

    @Override
    public ResourceLocation getBasicId() {
        return this.identifier.comp_2875().method_45138(modelType + "/");
    }

    @Override
    public ModelResourceLocation getModelId() {
        return this.identifier;
    }

    public JsonObject jsonModel() {
        return this.jsonModel;
    }

    @Override
    public BlockModel bake() {
        BlockModel unbakedModel = BlockModel.fromString(jsonModel.toString());
        unbakedModel.name = identifier.comp_2875().toString();
        return unbakedModel;
    }

    @Override
    public String toString() {
        return "LibyJsonModel{\n" +
                identifier.toString() + "\n" +
                jsonModel.toString() + "\n" +
                "}";
    }
}
