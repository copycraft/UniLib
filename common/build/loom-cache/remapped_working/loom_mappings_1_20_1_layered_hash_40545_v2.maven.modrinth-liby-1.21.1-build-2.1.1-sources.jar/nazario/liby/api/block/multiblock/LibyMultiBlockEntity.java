package nazario.liby.api.block.multiblock;

import nazario.liby.api.util.nbt.LibyNbtCompoundBuilder;
import nazario.liby.api.util.nbt.LibyNbtCompoundReader;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public abstract class LibyMultiBlockEntity extends BlockEntity {

    public BlockPos parentPos;
    public boolean destroyed;

    public LibyMultiBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public void setParentPos(BlockPos parentPos) {
        this.parentPos = parentPos;
    }

    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

    public BlockPos getParentPos() {
        return this.parentPos;
    }

    public boolean isDestroyed() {
        return this.destroyed;
    }

    @Override
    protected void method_11014(CompoundTag nbt, HolderLookup.Provider registryLookup) {
        LibyNbtCompoundReader reader = LibyNbtCompoundReader.create(nbt);

        this.parentPos = reader.getBlockPos("parentPos");
        this.destroyed = reader.asCompound().getBoolean("destroyed");

        super.load(nbt, registryLookup);
    }

    @Override
    protected void method_11007(CompoundTag nbt, HolderLookup.Provider registryLookup) {
        LibyNbtCompoundBuilder builder = LibyNbtCompoundBuilder.create(nbt);

        builder.putBlockPos("parentPos", this.parentPos);
        builder.putBoolean("destroyed", this.destroyed);

        super.saveAdditional(nbt, registryLookup);
    }
}
