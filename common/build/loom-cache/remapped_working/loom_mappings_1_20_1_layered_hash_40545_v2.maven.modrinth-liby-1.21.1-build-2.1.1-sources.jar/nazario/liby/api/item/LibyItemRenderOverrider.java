package nazario.liby.api.item;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.class_9779;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public interface LibyItemRenderOverrider {
    default void liby$renderItemInHand(float tickDelta, PoseStack matrices, MultiBufferSource.BufferSource vertexConsumers, LocalPlayer player, int light, CallbackInfo ci) {
    }

    default void liby$renderPlayer(PlayerRenderer playerEntityRenderer, AbstractClientPlayer player, float tickDelta, float g, PoseStack matrixStack, MultiBufferSource vertexConsumerProvider, int light, CallbackInfo ci) {
    }

    default void liby$shouldRenderPlayer(EntityRenderer<Player> playerEntityRenderer, Player player, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
    }

    default void liby$animateArmSwing(Entity entity, HumanoidModel<? extends LivingEntity> model, float animationProgress, CallbackInfo ci) {
    }

    default void liby$setPlayerModelAngles(LivingEntity livingEntity, float f, float g, float h, float i, float j, HumanoidModel<? extends LivingEntity> model, CallbackInfo ci) {
    }

    default void liby$animateHoldingItem(ModelPart holdingArm, ModelPart otherArm, ModelPart head, HumanoidModel<? extends LivingEntity> model, boolean rightArmed, CallbackInfo ci) {
    }

    default void liby$renderItemHud(GuiGraphics drawContext, class_9779 renderTickCounter, ItemStack stack) {
    }
}
