package nazario.liby.api.registry.runtime.models;

import java.util.List;
import net.minecraft.class_9824;
import net.minecraft.resources.ResourceLocation;

public abstract class LibyBlockState {
    public ResourceLocation id;
    public String resourcePackName;

    public ResourceLocation getId() {
        return this.id;
    }

    public List<class_9824.class_7777> createTrackedData() {
        return List.of();
    }
}
