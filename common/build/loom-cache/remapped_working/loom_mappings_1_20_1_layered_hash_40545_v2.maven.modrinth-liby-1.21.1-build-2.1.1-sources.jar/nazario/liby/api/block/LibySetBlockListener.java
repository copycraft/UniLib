package nazario.liby.api.block;

import net.minecraft.commands.arguments.blocks.BlockInput;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public interface LibySetBlockListener {
    default void setBlockStateEventHead(BlockInput blockStateArgument, ServerLevel world, BlockPos pos, int flags, CallbackInfoReturnable<Boolean> cir) {
    }

    ;

    default void setBlockStateEventTail(BlockInput blockStateArgument, ServerLevel world, BlockPos pos, int flags, CallbackInfoReturnable<Boolean> cir) {
    }

    ;
}
