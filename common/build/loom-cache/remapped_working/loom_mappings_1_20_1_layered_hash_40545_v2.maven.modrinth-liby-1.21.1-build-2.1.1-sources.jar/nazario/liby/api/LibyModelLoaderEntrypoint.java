package nazario.liby.api;

import nazario.liby.api.registry.rendering.LibyItemSpecialModelRegistry;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.ItemLike;

public interface LibyModelLoaderEntrypoint {
    void onLibyModelLoaderInitialize();

    default void liby$addModel(ModelResourceLocation modelIdentifier) {
        LibyItemSpecialModelRegistry._addModel(modelIdentifier);
    }

    default void liby$registerSpecialItemModel(ItemLike itemConvertible, ModelResourceLocation modelIdentifier, ItemDisplayContext... modes) {
        LibyItemSpecialModelRegistry._addModel(modelIdentifier);
        LibyItemSpecialModelRegistry.register(itemConvertible, modelIdentifier, modes);
    }
}
