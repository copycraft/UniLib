package nazario.liby.api.registry.helper;

import nazario.liby.registry.AbstractRegister;
import nazario.liby.registry.LibyClientEntityTypeList;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

public class LibyEntityTypeRegister extends AbstractRegister {
    public LibyEntityTypeRegister(String namespace) {
        super(namespace);
    }

    public EntityType<? extends Entity> registerEntityType(String name, FabricEntityTypeBuilder<? extends Entity> builder, EntityRendererProvider<? extends Entity> rendererFactory) {
        EntityType<? extends Entity> type = registerEntityType(name, builder);
        LibyClientEntityTypeList.entityRenderList.put(type, rendererFactory);
        return type;
    }

    public EntityType<? extends Entity> registerEntityType(String name, FabricEntityTypeBuilder<? extends Entity> builder) {
        EntityType<? extends Entity> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.method_60655(this.namespace, name), builder.build());
        return type;
    }

    public EntityType<? extends LivingEntity> registerEntityType(String name, FabricEntityTypeBuilder<? extends LivingEntity> builder, AttributeSupplier.Builder attributeBuilder) {
        EntityType<? extends LivingEntity> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.method_60655(this.namespace, name), builder.build());
        FabricDefaultAttributeRegistry.register(type, attributeBuilder.build());
        return type;
    }

    public EntityType<? extends LivingEntity> registerEntityType(String name, FabricEntityTypeBuilder<? extends LivingEntity> builder, AttributeSupplier.Builder attributeBuilder, EntityRendererProvider<? extends LivingEntity> rendererFactory) {
        EntityType<? extends LivingEntity> type = registerEntityType(name, builder, attributeBuilder);
        LibyClientEntityTypeList.entityRenderList.put(type, rendererFactory);
        return type;
    }
}
