package nazario.liby.api.registry.runtime.recipe.types;

import com.google.gson.JsonObject;
import nazario.liby.api.registry.runtime.recipe.LibyIngredient;
import nazario.liby.api.registry.runtime.recipe.LibyRecipe;
import net.minecraft.resources.ResourceLocation;

public class LibyStoneCuttingRecipe extends LibyRecipe {
    private static final ResourceLocation TYPE = ResourceLocation.method_60655("minecraft", "stonecutting");

    public LibyStoneCuttingRecipe(ResourceLocation id, LibyIngredient ingredient, ResourceLocation result, int count) {
        JsonObject recipe = new JsonObject();
        recipe.addProperty("type", getType().toString());

        JsonObject ingredientObject = new JsonObject();
        ingredientObject.addProperty(ingredient.getType(), ingredient.getIngredientId().toString());

        recipe.add("ingredient", ingredientObject);

        JsonObject resultObject = new JsonObject();
        resultObject.addProperty("id", result.toString());
        resultObject.addProperty("count", count);

        // Add result
        recipe.add("result", resultObject);

        this.jsonObject = recipe;
        this.id = id;
    }

    @Override
    protected ResourceLocation getType() {
        return TYPE;
    }
}
