package nazario.liby.api.registry.runtime.models;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_9824;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Tuple;

public class LibyMultipartBlockState extends LibyBlockState {

    protected List<JsonObject> variants;

    public LibyMultipartBlockState(ResourceLocation id, String resourcePackName) {
        this.id = id;
        this.resourcePackName = resourcePackName;
        this.variants = new ArrayList<>();
    }

    public LibyMultipartBlockState addState(String model, Tuple<String, Object>... when) {
        return this.addState(model, 0, 0, false, 1, when);
    }

    public LibyMultipartBlockState addState(String model, int x_rotation, int y_rotation, boolean uv_lock, int weight, Tuple<String, Object>... when) {
        JsonObject mainObject = new JsonObject();

        JsonObject applyObject = new JsonObject();
        applyObject.addProperty("model", model);
        applyObject.addProperty("x", x_rotation);
        applyObject.addProperty("y", y_rotation);
        applyObject.addProperty("uv_lock", uv_lock);
        applyObject.addProperty("weight", weight);

        mainObject.add("apply", applyObject);

        if(when.length > 0) {
            JsonObject whenObject = new JsonObject();

            for(Tuple<String, Object> pair : when) {
                if(pair.getB() instanceof Boolean bool) whenObject.addProperty(pair.getA(), bool ? "true" : "false");
                if(pair.getB() instanceof String string) whenObject.addProperty(pair.getA(), string);
                if(pair.getB() instanceof Integer integer) whenObject.addProperty(pair.getA(), integer);
            }

            mainObject.add("when", whenObject);
        }

        variants.add(mainObject);

        return this;
    }

    @Override
    public List<class_9824.class_7777> createTrackedData() {
        JsonObject mainJson = new JsonObject();

        JsonArray multipartArray = new JsonArray();

        for(JsonObject variant : variants) {
            multipartArray.add(variant);
        }

        mainJson.add("multipart", multipartArray);

        return List.of(new class_9824.class_7777(resourcePackName, mainJson));
    }
}
