package nazario.liby.api.registry.runtime.recipe;

import nazario.liby.runtime.resources.LibyJsonObject;
import net.minecraft.resources.ResourceLocation;

public abstract class LibyRecipe extends LibyJsonObject {
    protected ResourceLocation getType() {
        return ResourceLocation.method_60655("minecraft","none");
    }
}
