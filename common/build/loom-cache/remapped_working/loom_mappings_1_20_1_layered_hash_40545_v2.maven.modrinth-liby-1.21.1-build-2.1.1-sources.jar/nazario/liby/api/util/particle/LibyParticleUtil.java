package nazario.liby.api.util.particle;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

public class LibyParticleUtil {

    public static Vec3 drawCircle(Vec3 startingPos, int point, int maxPoints, double radiusX, double radiusY, double radiusZ) {
        double angle = 2d * Math.PI * point / maxPoints;
        double x = startingPos.x + radiusX * Math.cos(angle);
        double y = startingPos.y + radiusY * Math.sin(angle);
        double z = startingPos.z + radiusZ * Math.sin(angle);

        return new Vec3(x, y, z);
    }

    public static Vec3 drawCylinder(Vec3 startingPos, int point, int maxPoints, double radiusX, double radiusZ, double height) {
        double angle = 2d * Math.PI * point / maxPoints; // Determine the angle for circular points
        double x = startingPos.x + radiusX * Math.cos(angle); // X position for the circle
        double y = startingPos.y + height;        // Y position based on height and progress
        double z = startingPos.z + radiusZ * Math.sin(angle); // Z position for the circle

        return new Vec3(x, y, z);
    }

    public static Vec3 drawLine(Vec3 start, Vec3 end, int point, int maxPoints) {
        double dx = (end.x - start.x) / maxPoints;
        double dy = (end.y - start.y) / maxPoints;
        double dz = (end.z - start.z) / maxPoints;

        return new Vec3(start.x + point * dx, start.y + point * dy, start.z + point * dz);
    }

    public static void drawShape(LibyParticleData data, int maxPoints, Vec3 ankerPoint, Vec3... points) {
        for (int i = 0; i < points.length; i++) {
            if (i == points.length - 1) break;
            for (int j = 0; j < maxPoints; j++) {
                Vec3 point = drawLine(points[i], points[i + 1], j, maxPoints);
                point = point.add(ankerPoint);

                if (data.important)
                    data.world.addAlwaysVisibleParticle(data.particleEffect, data.alwaysSpawns, point.x, point.y, point.z, data.velocity.x, data.velocity.y, data.velocity.z);
                else
                    data.world.addParticle(data.particleEffect, data.alwaysSpawns, point.x, point.y, point.z, data.velocity.x, data.velocity.y, data.velocity.z);
            }
        }
    }

    public static void drawParticleData(LibyParticleData data, Vec3 position) {
        ((ServerLevel) data.world).sendParticles(data.particleEffect, position.x(), position.y(), position.z(), 1, data.velocity.x(), data.velocity.y(), data.velocity.z(), 0);
    }
}
