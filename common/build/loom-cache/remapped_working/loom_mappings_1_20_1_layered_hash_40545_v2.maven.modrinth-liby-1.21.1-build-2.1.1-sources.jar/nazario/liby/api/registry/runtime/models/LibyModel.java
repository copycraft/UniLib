package nazario.liby.api.registry.runtime.models;

import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.resources.ResourceLocation;

public interface LibyModel {
    ModelResourceLocation getModelId();
    ResourceLocation getBasicId();
    UnbakedModel bake();
}
