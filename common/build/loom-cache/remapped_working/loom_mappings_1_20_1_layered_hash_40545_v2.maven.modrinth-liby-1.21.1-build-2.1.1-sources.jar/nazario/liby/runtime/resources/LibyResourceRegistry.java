package nazario.liby.runtime.resources;

import com.google.gson.JsonElement;
import org.jetbrains.annotations.ApiStatus;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;

@ApiStatus.Internal
public abstract class LibyResourceRegistry {

    protected final Map<ResourceLocation, JsonElement> resourceMap = new HashMap<>();

    protected void addResource(LibyJsonObject resourceObject) {
        resourceMap.put(resourceObject.getId(), resourceObject.create());
    }

    public Map<ResourceLocation, JsonElement> getResourceMap() {
        return resourceMap;
    }

}
