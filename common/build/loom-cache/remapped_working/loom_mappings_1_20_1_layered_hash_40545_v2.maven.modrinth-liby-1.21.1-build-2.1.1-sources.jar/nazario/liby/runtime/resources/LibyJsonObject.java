package nazario.liby.runtime.resources;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public abstract class LibyJsonObject {
    protected ResourceLocation id;
    protected JsonObject jsonObject;

    public JsonObject create() {
        return this.jsonObject;
    }

    public ResourceLocation getId() {
        return this.id;
    }
}
