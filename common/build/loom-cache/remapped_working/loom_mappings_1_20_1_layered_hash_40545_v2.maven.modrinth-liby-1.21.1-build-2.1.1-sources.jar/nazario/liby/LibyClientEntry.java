package nazario.liby;

import nazario.liby.api.LibyModelLoaderEntrypoint;
import nazario.liby.api.block.rendering.LibyTransparentTextureBlock;
import nazario.liby.api.item.LibyItemRenderOverrider;
import nazario.liby.registry.LibyClientEntityTypeList;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;

public class LibyClientEntry implements ClientModInitializer, LibyModelLoaderEntrypoint {

    @Override
    public void onInitializeClient() {
        LibyClientEntityTypeList.entityRenderList.forEach((entityType, entityRenderer) -> {
            try {
                registerEntityRenderer(entityType, entityRenderer);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        for (Block block : BuiltInRegistries.BLOCK) {
            if (block.getClass().isAnnotationPresent(LibyTransparentTextureBlock.class)) {
                BlockRenderLayerMap.INSTANCE.putBlock(block, RenderType.cutout());
            }
        }

        HudRenderCallback.EVENT.register((drawContext, renderTickCounter) -> {
            class_310.method_1551().field_1724.method_5877().forEach(stack -> {
                if (stack != null) {
                    if (stack.method_7909() instanceof LibyItemRenderOverrider customHudRender) {
                        customHudRender.liby$renderItemHud(drawContext, renderTickCounter, stack);
                    }
                }
            });
        });
    }

    private static <E extends Entity> void registerEntityRenderer(EntityType<? extends Entity> entityType, EntityRendererProvider<? extends Entity> rendererFactory) {
        EntityRendererRegistry.register((EntityType<E>) entityType, (EntityRendererProvider<E>) rendererFactory);
    }

    @Override
    public void onLibyModelLoaderInitialize() {

    }
}
