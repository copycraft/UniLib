package nazario.liby.registry;

import java.util.HashMap;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

public class LibyClientEntityTypeList {
    public static final HashMap<EntityType<? extends Entity>, EntityRendererProvider<? extends Entity>> entityRenderList = new HashMap<>();
}
