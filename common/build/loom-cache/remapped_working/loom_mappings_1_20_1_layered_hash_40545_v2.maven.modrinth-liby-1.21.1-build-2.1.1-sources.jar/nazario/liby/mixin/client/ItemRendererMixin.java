package nazario.liby.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import nazario.liby.api.registry.rendering.LibyItemSpecialModelRegistry;
import nazario.liby.api.registry.runtime.models.LibyItemModelObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @ModifyVariable(method = "renderItem", at = @At("HEAD"), argsOnly = true)
    public BakedModel liby$renderItem(BakedModel value, ItemStack stack, ItemDisplayContext renderMode, boolean leftHanded, PoseStack matrices, MultiBufferSource vertexConsumers, int light, int overlay) {

        if (LibyItemSpecialModelRegistry.getList().containsKey(stack.getItem())) {
            LibyItemModelObject modelObject = LibyItemSpecialModelRegistry.getList().get(stack.getItem());
            if (!modelObject.containsMode(renderMode)) {
                return ((ItemRendererAccessor) this).liby$getModels().getModelManager().getModel(modelObject.modelIdentifier);
            }
        }

        return value;
    }
}
