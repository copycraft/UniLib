package nazario.liby.mixin;

import nazario.liby.api.block.LibySetBlockListener;
import net.minecraft.commands.arguments.blocks.BlockInput;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockInput.class)
public abstract class BlockStateArgumentMixin {
    @Inject(method = "setBlockState", at = @At("HEAD"), cancellable = true)
    public void liby$setBlockStateHead(ServerLevel world, BlockPos pos, int flags, CallbackInfoReturnable<Boolean> cir) {
        BlockInput blockStateArgument = (BlockInput) (Object) this;

        if (blockStateArgument.getState().getBlock() instanceof LibySetBlockListener listener) {
            listener.setBlockStateEventHead(blockStateArgument, world, pos, flags, cir);
        }
    }

    @Inject(method = "setBlockState", at = @At("TAIL"), cancellable = true)
    public void liby$setBlockStateTail(ServerLevel world, BlockPos pos, int flags, CallbackInfoReturnable<Boolean> cir) {
        BlockInput blockStateArgument = (BlockInput) (Object) this;

        if (blockStateArgument.getState().getBlock() instanceof LibySetBlockListener listener) {
            listener.setBlockStateEventHead(blockStateArgument, world, pos, flags, cir);
        }
    }
}
