package nazario.liby.mixin.client;

import nazario.liby.api.item.LibyItemRenderOverrider;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void liby$shouldRender(Entity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof Player playerEntity) {
            if (playerEntity.getMainHandItem().getItem() instanceof LibyItemRenderOverrider customItemPlayerRenderer) {
                customItemPlayerRenderer.liby$shouldRenderPlayer((EntityRenderer<Player>) (Object) this, playerEntity, frustum, x, y, z, cir);
            }
        }
    }
}
