package nazario.liby.mixin;

import com.google.gson.JsonElement;
import nazario.liby.api.registry.runtime.recipe.LibyRecipeRegistry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.RecipeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.Map;

@Mixin(RecipeManager.class)
public abstract class RecipeManagerMixin {

    @ModifyVariable(method = "apply(Ljava/util/Map;Lnet/minecraft/resource/ResourceManager;Lnet/minecraft/util/profiler/Profiler;)V", at = @At("HEAD"), order = 1, argsOnly = true)
    private Map<ResourceLocation, JsonElement> liby$apply(Map<ResourceLocation, JsonElement> map) {
        LibyRecipeRegistry.get().getResourceMap().forEach(map::putIfAbsent);
        return map;
    }
}
