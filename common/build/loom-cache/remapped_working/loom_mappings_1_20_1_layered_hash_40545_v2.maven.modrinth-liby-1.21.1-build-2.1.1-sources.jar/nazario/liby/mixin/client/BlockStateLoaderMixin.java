package nazario.liby.mixin.client;

import nazario.liby.api.registry.runtime.models.LibyModelRegistry;
import net.minecraft.class_9824;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Map;

@Mixin(class_9824.class)
public class BlockStateLoaderMixin {

    @Redirect(method = "loadBlockStates", at = @At(value = "INVOKE", target = "Ljava/util/Map;getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"))
    public <K, V> V liby$loadBlockStates(Map<K, V> blockStatesMap, K id, V defaultValue) {
        V object = blockStatesMap.getOrDefault(id, defaultValue);

        ResourceLocation cleanId = ResourceLocation.method_60655(((ResourceLocation)id).getNamespace(), ((ResourceLocation)id).getPath().replace(".json","").replace("blockstates/",""));

        if(LibyModelRegistry.getBlockStateMap().get(cleanId) != null) {
            return (V)LibyModelRegistry.getBlockStateMap().get(cleanId).createTrackedData();
        }

        return object;
    }
}
