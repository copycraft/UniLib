package nazario.liby.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import nazario.liby.api.item.LibyItemRenderOverrider;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerRenderer.class)
public abstract class PlayerEntityRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("TAIL"))
    public void liby$render(AbstractClientPlayer player, float tickDelta, float g, PoseStack matrixStack, MultiBufferSource vertexConsumerProvider, int light, CallbackInfo ci) {
        if (player.getMainHandItem().getItem() instanceof LibyItemRenderOverrider customItemPlayerRenderer) {
            customItemPlayerRenderer.liby$renderPlayer((PlayerRenderer) (Object) this, player, tickDelta, g, matrixStack, vertexConsumerProvider, light, ci);
        }
    }
}
