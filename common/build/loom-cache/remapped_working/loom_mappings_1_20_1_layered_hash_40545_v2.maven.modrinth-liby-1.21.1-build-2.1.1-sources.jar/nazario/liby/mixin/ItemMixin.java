package nazario.liby.mixin;

import nazario.liby.api.item.LibyItemExtendedMethods;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;

@Mixin(Item.class)
public abstract class ItemMixin implements LibyItemExtendedMethods {
    @Unique
    private Item.Properties itemSettings;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void liby$init(Item.Properties settings, CallbackInfo ci) {
        this.itemSettings = settings;
    }

    @Override
    public ResourceLocation liby$getId() {
        return ((Item) (Object) this).builtInRegistryHolder().unwrapKey().get().location();
    }

    @Override
    public Optional<Item.Properties> liby$getItemSettings() {
        return Optional.of(itemSettings);
    }
}
