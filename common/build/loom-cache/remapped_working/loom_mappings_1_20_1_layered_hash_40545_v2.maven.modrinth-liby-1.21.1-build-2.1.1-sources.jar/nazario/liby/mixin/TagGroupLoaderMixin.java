package nazario.liby.mixin;

import nazario.liby.api.registry.runtime.tags.LibyTagRegistry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.tags.TagLoader;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Mixin(TagLoader.class)
public abstract class TagGroupLoaderMixin {
    @Inject(method = "loadTags", at = @At("RETURN"))
    private void liby$loadTags(ResourceManager manager, CallbackInfoReturnable<Map<ResourceLocation, List<TagLoader.EntryWithSource>>> cir) {
        // Ensure the tag group loader and its data type map exist
        TagLoader<?> tagGroupLoader = (TagLoader<?>)(Object)this;
        Map<ResourceLocation, List<TagLoader.EntryWithSource>> additionalTags = LibyTagRegistry.getMap().get(tagGroupLoader.directory);

        if (additionalTags != null) {
            for (Map.Entry<ResourceLocation, List<TagLoader.EntryWithSource>> entry : additionalTags.entrySet()) {
                // Merge the lists instead of overwriting
                cir.getReturnValue().merge(entry.getKey(), entry.getValue(), (existingList, newList) -> {
                    // Combine existing and new lists
                    List<class_3503.class_5145> mergedList = new ArrayList<>(existingList);
                    mergedList.addAll(newList);
                    return mergedList;
                });
            }
        }
    }
}