package nazario.liby.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import nazario.liby.api.item.LibyItemRenderOverrider;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.client.renderer.ItemInHandRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At("HEAD"))
    public void liby$renderItem(float tickDelta, PoseStack matrices, MultiBufferSource.BufferSource vertexConsumers, LocalPlayer player, int light, CallbackInfo ci) {
        player.getHandSlots().forEach(itemStack -> {
            if (itemStack.getItem() instanceof LibyItemRenderOverrider customItemPlayerRenderer) {
                customItemPlayerRenderer.liby$renderItemInHand(tickDelta, matrices, vertexConsumers, player, light, ci);
            }
        });
    }
}
