package nazario.liby.mixin;

import nazario.liby.api.block.LibyBlockExtendedMethods;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Block.class)
public abstract class BlockMixin implements LibyBlockExtendedMethods {
    @Override
    public ResourceLocation liby$getId() {
        return ((Block)(Object) this).builtInRegistryHolder().unwrapKey().get().location();
    }
}
